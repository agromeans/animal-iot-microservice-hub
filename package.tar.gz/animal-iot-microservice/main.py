# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify
from lib.logger_opt import *
from lib.exception_opt import ExceptionCommon
import jsonschema
from jsonschema import validate
import lib.schema_opt as schema_opt
import lib.opt as opt
import lib.util_opt as util
import lib.scheduler_opt as scheduler_opt
import json
import config

app = Flask(__name__)


### 取得上傳資料，依照資料種類，將對應圖片上傳至伺服器 ###
@app.route('/upload_records', methods=['POST'])
def upload_records():
    try:
        message = request.json
    except Exception as e:
        raise ExceptionCommon(message=str(e))
        
    logger.info(f"'{request.path}' request and message:\n{message}")
    try:
        validate(instance=message, schema=schema_opt.schema_upload_records)
    except jsonschema.exceptions.ValidationError as e:
        raise ExceptionCommon(message='Json format is not valid.')
        
    # 1.write to sqlite, uploaded is default value(false)
    type = opt.write_to_sqlite(message)
    
    # 2.select, upload and delete records
    opt.upload_type_records(type)
    
    # 3.upload files to server
    opt.split_upload_files_to_server(type)
    
    response = dict(status_code=200, message='')
    return jsonify(response), 200
    
### 回傳設備中央側深與水平檢查結果 ###
@app.route('/detect/depth', methods=['POST'])
def detect_depth():
    try:
        message = request.json
    except Exception as e:
        raise ExceptionCommon(message=str(e))
        
    message = opt.detect_depth(message)
    response = dict(status_code=200, message=message)
    
    return jsonify(response), 200
    
### 取得GPIO所有狀態 ###
# @app.route('/iot/gpio/status/get', methods=['POST'])
def iot_gpio_status_get():
    try:
        message = request.json
    except Exception as e:
        raise ExceptionCommon(message=str(e))
        
    logger.info(f"'{request.path}' request and message:\n{message}")
    message = opt.iot_gpio_status_get(message)
    response = dict(status_code=200, message=message)
    
    return jsonify(response), 200
    
### 立即觸發偵測產量作業 ###
@app.route('/iot/gpio/yield/capture', methods=['POST'])
def iot_gpio_yield_capture():
    try:
        message = request.json
    except Exception as e:
        raise ExceptionCommon(message=str(e))
        
    logger.info(f"'{request.path}' request and message:\n{message}")
    opt.iot_gpio_yield_capture(message)
    
    response = dict(status_code=200, message='')
    return jsonify(response), 200
    
### 立即觸發感應器作業 ###
@app.route('/iot/gpio/sensor/capture', methods=['POST'])
def iot_gpio_sensor_capture():
    try:
        message = request.json
    except Exception as e:
        raise ExceptionCommon(message=str(e))
        
    logger.info(f"'{request.path}' request and message:\n{message}")
    opt.iot_gpio_sensor_capture(message)
    
    response = dict(status_code=200, message='')
    return jsonify(response), 200
    
@app.route('/iot/component/version', methods=['GET'])
def iot_component_version():
    message = opt.iot_component_version()
    response = dict(status_code=200, message=message)
    
    return jsonify(response), 200
    
@app.route('/version', methods=['GET'])
def version():
    return config.get_version()
    
@app.route('/', methods=['GET'])
def index():
    response = dict(status_code=200, message=util.checkResource())
    
    return jsonify(response), 200
    
@app.errorhandler(ExceptionCommon)
def handle_invalid_usage(error):
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response
    
@app.errorhandler(404)
def page_not_found(error):
    response = dict(status_code=404, message='404 Not Found')
    return jsonify(response), 404
    
@app.errorhandler(500)
def handle_500(error):
    response = dict(status_code=500, message='500 Error')
    return jsonify(response), 500
    
    
if __name__ == "__main__":
    config.reload_config()
    
    logger.info('====Check if the token exists...====')
    while True:
        try:
            config.get_token()
            if config.token:
                logger.info(f"====Token exists: '{config.token}'====")
                break
            util.get_info_from_server()
            time.sleep(5)
        except Exception as e:
            logger.error(str(e))
            time.sleep(5)
            
    logger.info('====The program is starting====')
    try:
        opt.license_get_from_server()
    except:
        pass
    scheduler_opt.run()
    
    app.run(host='0.0.0.0', port=3360, threaded=True, ssl_context='adhoc')
    