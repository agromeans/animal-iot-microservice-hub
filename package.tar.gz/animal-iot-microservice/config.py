# -*- coding: utf-8 -*-
from configparser import ConfigParser
from lib.logger_opt import *

config_file = 'config.ini'
config = ConfigParser()
config.read(config_file)

version = ''
record_keep_days = ''
countdown_minutes = ''

path_token = ''
path_record_sqlite = ''
token = ''

frp_server = ''
frp_user = ''

api_geocode_url = ''

api_server_ip_port = ''
file_server_ip_port = ''
api_owner_get = ''
api_upload_records = ''
api_upload_file = ''

api_status_get = ''
api_sensor_capture = ''
api_yield_capture = ''
api_detect_depth = ''

path_frpc_ini = 'frpc.ini'
path_raw_image_folder = 'images/raw'
path_ai_image_folder = 'images/ai'
path_heatmap_image_folder = 'images/heatmap'
path_raw_modify_image_folder = 'images/raw_modify'
path_flir_overlap_image_folder = 'images/flir_overlap'
path_flir_raw_image_folder = 'images/flir_raw'
path_raw_left_image_folder = 'images/raw_left'
path_raw_right_image_folder = 'images/raw_right'

path_nn_yolo = 'nn-yolo/version.txt'

upload_type_sensor = 'sensor'
upload_type_yield = 'yield'

def get_version():
    return version
    
def check_config_section():
    if not config.has_section('common'):
        config.add_section('common')
        
    if not config.has_section('path'):
        config.add_section('path')
        
    if not config.has_section('api'):
        config.add_section('api')
        
    config.write(open(config_file, 'w'))
    
def get_config():
    global version, record_keep_days, countdown_minutes, path_token, path_record_sqlite, api_geocode_url, api_server_ip_port, api_detect_depth, file_server_ip_port, api_owner_get, api_upload_records, api_upload_file, api_status_get, api_sensor_capture, api_yield_capture
    
    try:
        record_keep_days = int(config.get('common', 'record_keep_days'))
    except Exception as e:
        logger.warning(e)
        print(e)
        record_keep_days = 0
        
    try:
        countdown_minutes = int(config.get('common', 'countdown_minutes'))
    except Exception as e:
        logger.warning(e)
        print(e)
        countdown_minutes = 0
        
    try:
        version = config.get('common', 'version')
    except Exception as e:
        logger.warning(e)
        print(e)
        version = ''
        
    try:
        path_token = config.get('path', 'token')
    except Exception as e:
        logger.warning(e)
        print(e)
        path_token = ''
        
    try:
        path_record_sqlite = config.get('path', 'record_sqlite')
    except Exception as e:
        logger.warning(e)
        print(e)
        path_record_sqlite = ''
        
    try:
        api_geocode_url = config.get('api', 'geocode_url')
    except Exception as e:
        logger.warning(e)
        print(e)
        api_geocode_url = ''
        
    try:
        api_server_ip_port = config.get('api', 'api_server_ip_port')
    except Exception as e:
        logger.warning(e)
        print(e)
        api_server_ip_port = ''
        
    try:
        api_detect_depth = config.get('api', 'detect_depth')
    except Exception as e:
        logger.warning(e)
        print(e)
        api_detect_depth = ''
        
    try:
        file_server_ip_port = config.get('api', 'file_server_ip_port')
    except Exception as e:
        logger.warning(e)
        print(e)
        file_server_ip_port = ''
        
    try:
        api_owner_get = f"https://{api_server_ip_port}{config.get('api', 'owner_get')}"
    except Exception as e:
        logger.warning(e)
        print(e)
        api_owner_get = ''
        
    try:
        api_upload_records = f"https://{api_server_ip_port}{config.get('api', 'upload_records')}"
    except Exception as e:
        logger.warning(e)
        print(e)
        api_upload_records = ''
        
    try:
        api_upload_file = f"https://{file_server_ip_port}{config.get('api', 'upload_file')}"
    except Exception as e:
        logger.warning(e)
        print(e)
        api_upload_file = ''
        
    # try:
        # api_status_get = config.get('api', 'status_get')
    # except Exception as e:
        # logger.warning(e)
        # print(e)
        # api_status_get = ''
        
    try:
        api_sensor_capture = config.get('api', 'sensor_capture')
    except Exception as e:
        logger.warning(e)
        print(e)
        api_sensor_capture = ''
        
    try:
        api_yield_capture = config.get('api', 'yield_capture')
    except Exception as e:
        logger.warning(e)
        print(e)
        api_yield_capture = ''
        
def get_frpc():
    global frp_server, frp_user
    
    _config = ConfigParser()
    _config.read(path_frpc_ini)
    
    try:
        frp_server = _config.get('common', 'server_addr')
    except Exception as e:
        logger.warning(e)
        print(e)
        frp_server = ''
        
    try:
        frp_user = _config.get('ssh', 'remote_port')
    except Exception as e:
        logger.warning(e)
        print(e)
        frp_user = ''
        
    logger.info(f"====The device is using ssh frp: {frp_server}:{frp_user}====")
    
def get_token():
    global token
    
    try:
        with open(path_token, 'r') as f:
            token = f.readline().rstrip()
    except:
        token = ''
        
def reload_config():
    get_frpc()
    check_config_section()
    get_config()
    get_token()
    
def url_add_nat64(url):
    temp = url                               # http://208.95.112.1/json             # 20.191.97.53:3360
    if 'http://' in url:
        temp = url.replace('http://', '')    # 208.95.112.1/json                    # 20.191.97.53:3360
        
    temp_list = temp.split('/')              # ['208.95.112.1', 'json']             # ['20.191.97.53:3360']
    uri = temp_list[0]                       # 208.95.112.1                         # 20.191.97.53:3360
    
    uri_list = uri.split(':')                # ['208.95.112.1']                     # ['20.191.97.53', '3360']
    ip = uri_list[0]                         # 208.95.112.1                         # 20.191.97.53
    ip = f"[64:ff9b::{ip}]"                 # [64:ff9b::208.95.112.1]              # [64:ff9b::20.191.97.53]
    
    uri_list[0] = ip                         # ['[64:ff9b::208.95.112.1]']          # ['[64:ff9b::20.191.97.53]'. 3360]
    uri = ':'.join(uri_list)                 # [64:ff9b::208.95.112.1]              # [64:ff9b::20.191.97.53]:3360
    
    temp_list[0] = uri                       # ['[64:ff9b::208.95.112.1]', 'json']  # ['[64:ff9b::20.191.97.53]:3360']
    temp = '/'.join(temp_list)               # [64:ff9b::208.95.112.1]/json         # [64:ff9b::20.191.97.53]:3360
    
    if 'http://' in url:
        temp = f"http://{temp}"              # http://[64:ff9b::208.95.112.1]/json  # [64:ff9b::20.191.97.53]:3360
        
    return temp                              # http://[64:ff9b::208.95.112.1]/json  # [64:ff9b::20.191.97.53]:3360
    
if __name__ == '__main__':
    reload_config()
    